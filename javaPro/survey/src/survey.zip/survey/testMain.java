package survey;



public class testMain {
	public static void main(String[] args) {
		QuestionVO vo = new QuestionVO();
		new MainGUI(vo);
		
	
	}



}

