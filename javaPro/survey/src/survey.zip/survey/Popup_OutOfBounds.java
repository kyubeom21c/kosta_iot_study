package survey;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Popup_OutOfBounds extends JFrame {
	public Popup_OutOfBounds(QuestionVO vo) {
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("20���� ���Ϸ� �������ּ���..!");
		lblNewLabel.setBounds(131, 10, 195, 15);
		getContentPane().add(lblNewLabel);

		JButton btnNewButton = new JButton("���ư���.");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new CreateFormGUI(vo);
			}
		});
		btnNewButton.setBounds(120, 38, 149, 23);
		getContentPane().add(btnNewButton);

		setTitle("���� ȭ������ ���ư��ϴ�.");
		setBounds(300, 400, 400, 109);
		setVisible(true);
	}
}
